#!/usr/bin/env bash
# Actualiza FactuIA con los archivos de esta carpeta. Conserva la base de datos, las claves y la configuración.
# Uso:  sudo bash deploy/actualizar.sh
set -euo pipefail
APP=/opt/factuia
ORIGEN="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
[[ $EUID -eq 0 ]] || { echo "Ejecútalo con sudo." >&2; exit 1; }
[[ -d "$APP" ]] || { echo "FactuIA no está instalado todavía: usa instalar.sh." >&2; exit 1; }

/usr/local/bin/factuia-respaldo   # copia de seguridad antes de tocar nada
rsync -a --exclude venv --exclude semilla.json --exclude tests --exclude __pycache__ --exclude '*.db' --exclude .secret "$ORIGEN/" "$APP/"
"$APP/venv/bin/pip" install --quiet -r "$APP/requirements.txt"
chown -R root:root "$APP"
chmod -R go-w "$APP"
install -m 644 "$ORIGEN/deploy/factuia.service" /etc/systemd/system/factuia.service
systemctl daemon-reload
systemctl restart factuia
sleep 3
if curl -fsS -o /dev/null http://127.0.0.1:8000/; then
  echo "Actualizado y funcionando."
else
  echo "No responde: journalctl -u factuia -n 50 --no-pager" >&2
  exit 1
fi
