#!/usr/bin/env bash
# Copia de seguridad de la base de datos. Conserva 14 días en /var/backups/factuia.
set -euo pipefail
ORIGEN=/var/lib/factuia/factuia.db
DESTINO=/var/backups/factuia
[[ -f "$ORIGEN" ]] || exit 0
mkdir -p "$DESTINO"
chmod 700 "$DESTINO"
sqlite3 "$ORIGEN" ".backup '$DESTINO/factuia-$(date +%F).db'"
find "$DESTINO" -name 'factuia-*.db' -mtime +14 -delete
