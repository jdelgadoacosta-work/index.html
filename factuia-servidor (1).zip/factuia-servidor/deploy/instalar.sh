#!/usr/bin/env bash
# Instala FactuIA en un VPS Ubuntu 22.04 / 24.04 (Hostinger): Python, Nginx, HTTPS gratuito
# (Let's Encrypt), arranque automático y copias de seguridad diarias.
#
# Uso (desde la carpeta del proyecto, ya subida al servidor):
#   sudo bash deploy/instalar.sh tudominio.com tu@correo.com
set -euo pipefail

DOMINIO="${1:-}"
CORREO="${2:-}"
APP=/opt/factuia
DATOS=/var/lib/factuia
ENTORNO=/etc/factuia.env
ORIGEN="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

fallar() { echo "ERROR: $*" >&2; exit 1; }
paso() { echo; echo "==> $*"; }

[[ $EUID -eq 0 ]] || fallar "Ejecútalo con sudo:  sudo bash deploy/instalar.sh tudominio.com tu@correo.com"
[[ -n "$DOMINIO" && -n "$CORREO" ]] || fallar "Falta el dominio o el correo.  Uso: sudo bash deploy/instalar.sh tudominio.com tu@correo.com"
[[ "$DOMINIO" =~ ^[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]] || fallar "Dominio no válido: $DOMINIO (escríbelo sin https:// ni barras)"
[[ -f "$ORIGEN/app.py" && -f "$ORIGEN/deploy/nginx.conf" ]] || fallar "No encuentro app.py. Ejecuta el script desde la carpeta del proyecto."

paso "Comprobando que el dominio apunta a este servidor"
IP_SERVIDOR="$(curl -4 -fsS --max-time 10 https://api.ipify.org || true)"
IP_DOMINIO="$(getent ahostsv4 "$DOMINIO" | awk 'NR==1{print $1}' || true)"
if [[ -n "$IP_SERVIDOR" && "$IP_SERVIDOR" != "$IP_DOMINIO" && "${OMITIR_DNS:-0}" != "1" ]]; then
  fallar "$DOMINIO apunta a '${IP_DOMINIO:-nada}' y este servidor es $IP_SERVIDOR.
Crea en tu DNS un registro A de $DOMINIO hacia $IP_SERVIDOR, espera unos minutos y vuelve a ejecutar.
(Si acabas de crearlo y sabes que es correcto:  OMITIR_DNS=1 sudo -E bash deploy/instalar.sh ...)"
fi

paso "Instalando paquetes (Python, Nginx, Certbot, firewall)"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y python3 python3-venv python3-pip nginx certbot python3-certbot-nginx ufw sqlite3 rsync curl

paso "Creando el usuario del servicio y copiando la aplicación"
id factuia >/dev/null 2>&1 || useradd --system --home "$APP" --shell /usr/sbin/nologin factuia
mkdir -p "$APP" "$DATOS"
rsync -a --exclude venv --exclude semilla.json --exclude tests --exclude __pycache__ --exclude '*.db' --exclude .secret "$ORIGEN/" "$APP/"
python3 -m venv "$APP/venv"
"$APP/venv/bin/pip" install --quiet --upgrade pip
"$APP/venv/bin/pip" install --quiet -r "$APP/requirements.txt"
chown -R root:root "$APP"
chmod -R go-w "$APP"

paso "Creando la configuración privada ($ENTORNO)"
if [[ ! -f "$ENTORNO" ]]; then
  {
    echo "FACTUIA_SECRET=$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
    echo "FACTUIA_DB=$DATOS/factuia.db"
    echo "FACTUIA_HTTPS=1"
    echo "# Para enviar correos reales, quita el # y completa (ver deploy/env.ejemplo):"
    echo "#FACTUIA_SMTP_HOST="
  } > "$ENTORNO"
  chmod 600 "$ENTORNO"
else
  echo "Ya existía; no se toca."
fi

paso "Creando la base de datos con los usuarios de semilla.json"
if [[ -f "$DATOS/factuia.db" ]]; then
  echo "La base de datos ya existe; no se toca."
elif [[ -f "$ORIGEN/semilla.json" ]]; then
  TMP="$(mktemp)"
  cp "$ORIGEN/semilla.json" "$TMP"
  chown factuia:factuia "$TMP"
  chown -R factuia:factuia "$DATOS"
  (cd "$APP" && sudo -u factuia env FACTUIA_DB="$DATOS/factuia.db" "$APP/venv/bin/python" inicializar.py --semilla "$TMP")
  shred -u "$TMP"
  shred -u "$ORIGEN/semilla.json"
  echo "semilla.json borrado: las claves en texto plano ya no están en el servidor."
else
  fallar "No hay base de datos ni semilla.json. Sube semilla.json junto al proyecto y vuelve a ejecutar."
fi
chown -R factuia:factuia "$DATOS"
chmod 700 "$DATOS"

paso "Configurando el arranque automático"
install -m 644 "$ORIGEN/deploy/factuia.service" /etc/systemd/system/factuia.service
systemctl daemon-reload
systemctl enable --now factuia
sleep 3
curl -fsS -o /dev/null http://127.0.0.1:8000/ || fallar "La aplicación no responde. Revisa:  journalctl -u factuia -n 50 --no-pager"

paso "Configurando Nginx"
sed "s/__DOMINIO__/$DOMINIO/g" "$ORIGEN/deploy/nginx.conf" > /etc/nginx/sites-available/factuia
ln -sf /etc/nginx/sites-available/factuia /etc/nginx/sites-enabled/factuia
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx

paso "Abriendo solo los puertos necesarios (SSH, 80 y 443)"
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable

paso "Activando HTTPS gratuito con Let's Encrypt"
DOMINIOS=(-d "$DOMINIO")
if getent ahostsv4 "www.$DOMINIO" >/dev/null 2>&1; then DOMINIOS+=(-d "www.$DOMINIO"); fi
certbot --nginx --non-interactive --agree-tos --redirect -m "$CORREO" "${DOMINIOS[@]}"

paso "Programando copias de seguridad diarias"
install -m 755 "$ORIGEN/deploy/respaldo.sh" /usr/local/bin/factuia-respaldo
echo "15 3 * * * root /usr/local/bin/factuia-respaldo" > /etc/cron.d/factuia-respaldo

echo
echo "LISTO."
echo "  Portal del cliente:  https://$DOMINIO/"
echo "  Administración:      https://$DOMINIO/admin"
echo "Siguiente: entra a /admin y cambia la clave del administrador (ver GUIA-HOSTINGER.md)."
