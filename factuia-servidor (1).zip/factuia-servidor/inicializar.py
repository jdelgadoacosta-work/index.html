"""Crea la base de datos y registra a los clientes y al administrador de semilla.json.

    python inicializar.py                         # primera vez (no pisa lo que ya existe)
    python inicializar.py --clave-admin NUEVA     # cambia la clave del administrador
"""
import argparse
import json
import os
import sys

from app import BASE, sembrar

p = argparse.ArgumentParser()
p.add_argument("--clave-admin", help="nueva clave del administrador")
p.add_argument("--semilla", default=os.path.join(BASE, "semilla.json"))
args = p.parse_args()

semilla = {}
if os.path.exists(args.semilla):
    with open(args.semilla, encoding="utf-8") as f:
        semilla = json.load(f)
elif not args.clave_admin:
    sys.exit(f"No encuentro {args.semilla}.")

ruta = os.environ.get("FACTUIA_DB", os.path.join(BASE, "factuia.db"))
sembrar(ruta, semilla, args.clave_admin)
print(f"Base de datos lista en {ruta}")
