# FactuIA: servidor (portal del cliente + administración)

Servidor Flask con base de datos SQLite. Sirve las dos páginas y guarda de verdad usuarios, PIN, licencias, facturas y los módulos de cada empresa.

| Dirección | Qué es |
|---|---|
| `/` | Portal del cliente (`static/index.html`) |
| `/admin` | Administración (`static/admin.html`) |

## Puesta en marcha

```bash
pip install -r requirements.txt
python inicializar.py     # crea factuia.db con los usuarios y la clave de administrador de semilla.json
python app.py             # http://127.0.0.1:5000  ·  http://127.0.0.1:5000/admin
```

Después de inicializar, **borra `semilla.json`**: tiene las claves en texto plano. En la base de datos solo quedan hashes.
Cambiar la clave del administrador: `python inicializar.py --clave-admin NUEVA_CLAVE`

## Empresas y funciones

Toda empresa nace con las funciones iniciales: **facturar, facturas (con exportación a Excel), impuestos y cambio de PIN**.
Desde `/admin` se crean empresas nuevas y se activan o quitan, por empresa, estas funciones adicionales:

| Módulo | Qué hace hoy |
|---|---|
| Calendario | Eventos con fecha, hora y notas |
| Correos | Redacta y envía por SMTP (límite de 20 por hora). Sin SMTP configurado queda como borrador |
| Hojas de Excel | Hojas editables en pantalla (hasta 100 filas x 20 columnas) y descarga en `.xlsx` |
| Publicidad en redes | Planifica campañas (red, texto, presupuesto, fechas, estado) y abre la publicación en X, LinkedIn y WhatsApp, o copia el texto para Facebook, Instagram y TikTok |

Límites actuales: los correos solo se envían (no hay bandeja de entrada), y la publicidad no publica sola: publicar automáticamente exige crear y aprobar una aplicación en la API de cada red.

Para enviar correos reales define: `FACTUIA_SMTP_HOST`, `FACTUIA_SMTP_PORT` (587 por defecto), `FACTUIA_SMTP_USER`, `FACTUIA_SMTP_PASSWORD` y `FACTUIA_SMTP_FROM`.

## Pruebas

```bash
python -m unittest discover -s tests -v
```

## Seguridad: lo que ya hace

- Contraseña, documento y PIN se guardan solo como hash con sal.
- Cinco intentos fallidos bloquean al usuario (o al administrador) cinco minutos.
- Un bloqueo por falta de pago se aplica en la siguiente petición, aunque el cliente tenga la sesión abierta.
- Cada empresa solo ve y toca sus propios datos, y solo los módulos que el administrador le activó.
- En los archivos de Excel, lo que escribe el usuario es siempre texto, nunca una fórmula.
- Sesión por cookie `HttpOnly` y `SameSite=Lax`, y la API solo acepta JSON.

## Publicarlo en internet

Para Hostinger (VPS) sigue **`GUIA-HOSTINGER.md`**: los archivos están en `deploy/` y el instalador lo deja funcionando con HTTPS.

Otra opción, plataformas como Render o Railway:

El `Procfile` está listo para plataformas como Render o Railway (`gunicorn "app:crear_app()"`), que dan HTTPS por su cuenta. Allí define `FACTUIA_SECRET` (valor largo y aleatorio) y `FACTUIA_HTTPS=1`, y guarda `factuia.db` en un disco persistente: en un disco temporal los datos se pierden al reiniciar.

Variables de entorno: `FACTUIA_DB`, `FACTUIA_SECRET`, `FACTUIA_HTTPS`, `HOST`, `PORT` y las `FACTUIA_SMTP_*`.

## Aviso

Las facturas son documentos de gestión internos, no facturas electrónicas DIAN. Las tarifas son orientativas: confírmalas con tu contador.
