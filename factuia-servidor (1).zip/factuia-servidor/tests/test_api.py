import io
import os
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as appmod
from app import crear_app, sembrar

SEMILLA = {"admin": {"password": "clave-admin-test"},
           "clientes": [{"usuario": "uno", "password": "pw-uno", "documento": "10", "pin": "1111"},
                        {"usuario": "dos", "password": "pw-dos", "documento": "20", "pin": "2222"}]}
UNO = {"usuario": "uno", "password": "pw-uno", "documento": "10", "pin": "1111"}
DOS = {"usuario": "dos", "password": "pw-dos", "documento": "20", "pin": "2222"}
ITEM = {"descripcion": "cafe", "cantidad": 3, "precio": 10000}


class Base(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        ruta = os.path.join(tmp.name, "t.db")
        sembrar(ruta, SEMILLA)
        self.app = crear_app(ruta, "secreto-de-prueba")
        self.c = self.app.test_client()

    def entrar(self, cred=UNO, cliente=None):
        return (cliente or self.c).post("/api/login", json=cred)

    def admin(self):
        a = self.app.test_client()
        self.assertEqual(a.post("/api/admin/login", json={"password": "clave-admin-test"}).status_code, 200)
        return a


class TestAcceso(Base):
    def test_login_y_sesion(self):
        self.assertEqual(self.c.get("/api/yo").status_code, 401)
        self.assertEqual(self.entrar().status_code, 200)
        self.assertEqual(self.c.get("/api/yo").get_json()["usuario"], "uno")
        self.c.post("/api/logout", json={})
        self.assertEqual(self.c.get("/api/yo").status_code, 401)

    def test_error_generico(self):
        mal_pin = self.entrar({**UNO, "pin": "0000"})
        inexistente = self.entrar({"usuario": "nadie", "password": "x", "documento": "x", "pin": "x"})
        self.assertEqual((mal_pin.status_code, inexistente.status_code), (401, 401))
        self.assertEqual(mal_pin.get_json(), inexistente.get_json())

    def test_pin_de_otro_cliente_no_sirve(self):
        self.assertEqual(self.entrar({**UNO, "pin": DOS["pin"]}).status_code, 401)

    def test_bloqueo_tras_fallos(self):
        for _ in range(5):
            self.entrar({**UNO, "password": "mala"})
        self.assertEqual(self.entrar().status_code, 429)
        self.assertEqual(self.entrar(DOS, self.app.test_client()).status_code, 200)

    def test_exige_json(self):
        self.assertEqual(self.c.post("/api/login", data="usuario=uno").status_code, 415)


class TestPin(Base):
    def test_cambiar_pin(self):
        self.entrar()
        self.assertEqual(self.c.post("/api/pin", json={"actual": "9999", "nuevo": "1234"}).status_code, 400)
        self.assertEqual(self.c.post("/api/pin", json={"actual": "1111", "nuevo": "12"}).status_code, 400)
        self.assertEqual(self.c.post("/api/pin", json={"actual": "1111", "nuevo": "1111"}).status_code, 400)
        self.assertEqual(self.c.post("/api/pin", json={"actual": "1111", "nuevo": "1234"}).status_code, 200)
        self.assertEqual(self.entrar({**UNO, "pin": "1234"}, self.app.test_client()).status_code, 200)
        self.assertEqual(self.entrar(UNO, self.app.test_client()).status_code, 401)
        self.assertEqual(self.entrar(DOS, self.app.test_client()).status_code, 200)


class TestFacturas(Base):
    def test_calculo_numeracion_y_aislamiento(self):
        self.entrar()
        r = self.c.post("/api/facturas", json={"cliente": "Ana", "impuesto": "iva19", "items": [ITEM]})
        f = r.get_json()
        self.assertEqual((r.status_code, f["numero"], f["base"], f["impuesto"], f["total"]),
                         (201, "FI-00001", 30000, 5700, 35700))
        r2 = self.c.post("/api/facturas", json={"impuesto": "impoconsumo8", "items": [{**ITEM, "precio": 1250}]}).get_json()
        self.assertEqual((r2["numero"], r2["cliente"], r2["impuesto"]), ("FI-00002", "Consumidor final", 300))
        self.assertEqual([x["numero"] for x in self.c.get("/api/facturas").get_json()], ["FI-00002", "FI-00001"])
        otro = self.app.test_client()
        self.entrar(DOS, otro)
        self.assertEqual(otro.get("/api/facturas").get_json(), [])

    def test_validaciones(self):
        self.entrar()
        malos = [{"impuesto": "x", "items": [ITEM]}, {"impuesto": "iva19", "items": []},
                 {"impuesto": "iva19", "items": [{**ITEM, "cantidad": 0}]},
                 {"impuesto": "iva19", "items": [{**ITEM, "precio": -5}]},
                 {"impuesto": "iva19", "items": [{**ITEM, "precio": "NaN"}]},
                 {"impuesto": "iva19", "items": [{"descripcion": "a"}]}]
        for cuerpo in malos:
            self.assertEqual(self.c.post("/api/facturas", json=cuerpo).status_code, 400, cuerpo)

    def test_nit(self):
        self.entrar()
        self.c.put("/api/nit", json={"nit": "900123456-7"})
        self.assertEqual(self.c.get("/api/yo").get_json()["nit"], "900123456-7")


class TestAdmin(Base):
    def test_login_admin(self):
        self.assertEqual(self.c.get("/api/admin/clientes").status_code, 401)
        self.assertEqual(self.c.post("/api/admin/login", json={"password": "mala"}).status_code, 401)
        self.admin()

    def test_bloqueo_admin_tras_fallos(self):
        for _ in range(5):
            self.c.post("/api/admin/login", json={"password": "mala"})
        self.assertEqual(self.c.post("/api/admin/login", json={"password": "clave-admin-test"}).status_code, 429)

    def test_licencia_se_aplica_de_inmediato(self):
        a = self.admin()
        self.entrar()
        self.assertEqual(a.patch("/api/admin/clientes/uno", json={"activo": False}).status_code, 200)
        self.assertEqual(self.c.get("/api/yo").status_code, 403)
        self.assertEqual(self.c.post("/api/facturas", json={"impuesto": "iva19", "items": [ITEM]}).status_code, 403)
        self.assertEqual(self.entrar(UNO, self.app.test_client()).status_code, 403)
        a.patch("/api/admin/clientes/uno", json={"activo": True})
        self.assertEqual(self.c.get("/api/yo").status_code, 200)

    def test_alta_de_cliente_y_resumen(self):
        a = self.admin()
        nuevo = {"usuario": "tres", "password": "pw-tres", "documento": "30", "pin": "3333"}
        self.assertEqual(a.post("/api/admin/clientes", json=nuevo).status_code, 201)
        self.assertEqual(a.post("/api/admin/clientes", json=nuevo).status_code, 409)
        self.assertEqual(a.post("/api/admin/clientes", json={**nuevo, "usuario": "Mal Nombre"}).status_code, 400)
        self.assertEqual(self.entrar(nuevo).status_code, 200)
        self.c.post("/api/facturas", json={"impuesto": "iva5", "items": [ITEM]})
        fila = {x["usuario"]: x for x in a.get("/api/admin/clientes").get_json()}["tres"]
        self.assertEqual((fila["activo"], fila["facturas"], fila["total"]), (True, 1, 31500))
        self.assertEqual(a.patch("/api/admin/clientes/nadie", json={"activo": False}).status_code, 404)


class TestModulos(Base):
    def activar(self, a, usuario="uno", modulos=("calendario", "correos", "hojas", "publicidad")):
        self.assertEqual(a.patch(f"/api/admin/clientes/{usuario}", json={"modulos": list(modulos)}).status_code, 200)

    def test_modulo_apagado_por_defecto_y_el_admin_lo_activa(self):
        a = self.admin()
        r = self.entrar().get_json()
        self.assertEqual(r["modulos"], [])
        self.assertEqual(self.c.get("/api/m/calendario").status_code, 404)
        self.activar(a, modulos=("calendario",))
        self.assertEqual(self.c.get("/api/yo").get_json()["modulos"], ["calendario"])
        self.assertEqual(self.c.get("/api/m/calendario").status_code, 200)
        self.assertEqual(self.c.get("/api/m/correos").status_code, 404)
        self.assertEqual(self.c.get("/api/m/inventado").status_code, 404)
        self.assertEqual(a.patch("/api/admin/clientes/uno", json={"modulos": ["calendario", "otro"]}).status_code, 400)

    def test_cliente_nuevo_nace_igual_que_los_demas_y_puede_traer_modulos(self):
        a = self.admin()
        base = {"usuario": "tres", "password": "pw-tres", "documento": "30", "pin": "3333"}
        self.assertEqual(a.post("/api/admin/clientes", json=base).status_code, 201)
        self.assertEqual(self.entrar(base).get_json()["modulos"], [])
        extra = {**base, "usuario": "cuatro", "modulos": ["hojas"]}
        self.assertEqual(a.post("/api/admin/clientes", json=extra).status_code, 201)
        lista = {x["usuario"]: x for x in a.get("/api/admin/clientes").get_json()}
        self.assertEqual((lista["tres"]["modulos"], lista["cuatro"]["modulos"]), ([], ["hojas"]))
        self.assertEqual(a.post("/api/admin/clientes", json={**base, "usuario": "cinco", "modulos": ["x"]}).status_code, 400)

    def test_calendario(self):
        self.activar(self.admin())
        self.entrar()
        ok = self.c.post("/api/m/calendario", json={"titulo": "Pagar IVA", "fecha": "2026-11-20", "hora": "09:30"})
        self.assertEqual(ok.status_code, 201)
        rid = ok.get_json()["id"]
        for malo in ({"titulo": "x", "fecha": "2026-13-45"}, {"titulo": "x", "fecha": "2026-01-01", "hora": "25:99"}, {"fecha": "2026-01-01"}):
            self.assertEqual(self.c.post("/api/m/calendario", json=malo).status_code, 400, malo)
        self.assertEqual(self.c.put(f"/api/m/calendario/{rid}", json={"titulo": "Pagar IVA hoy", "fecha": "2026-11-21"}).status_code, 200)
        self.assertEqual(self.c.get("/api/m/calendario").get_json()[0]["titulo"], "Pagar IVA hoy")
        otro = self.app.test_client()
        self.entrar(DOS, otro)
        self.assertEqual(otro.get("/api/m/calendario").status_code, 404)  # DOS no tiene el módulo
        self.assertEqual(self.c.delete(f"/api/m/calendario/{rid}").status_code, 200)
        self.assertEqual(self.c.delete(f"/api/m/calendario/{rid}").status_code, 404)

    def test_datos_de_un_cliente_no_se_ven_ni_se_tocan_desde_otro(self):
        a = self.admin()
        self.activar(a, "uno", ("calendario",))
        self.activar(a, "dos", ("calendario",))
        self.entrar()
        rid = self.c.post("/api/m/calendario", json={"titulo": "privado", "fecha": "2026-01-01"}).get_json()["id"]
        otro = self.app.test_client()
        self.entrar(DOS, otro)
        self.assertEqual(otro.get("/api/m/calendario").get_json(), [])
        self.assertEqual(otro.put(f"/api/m/calendario/{rid}", json={"titulo": "robado", "fecha": "2026-01-01"}).status_code, 404)
        self.assertEqual(otro.delete(f"/api/m/calendario/{rid}").status_code, 404)

    def test_hojas_y_excel(self):
        from openpyxl import load_workbook
        self.activar(self.admin())
        self.entrar()
        filas = [["Producto", "Precio", "Código"], ["Café", "3500", "007"], ["=1+1", "2.5", "+57"]]
        rid = self.c.post("/api/m/hojas", json={"nombre": "Costos", "filas": filas}).get_json()["id"]
        self.assertEqual(self.c.post("/api/m/hojas", json={"nombre": "", "filas": filas}).status_code, 400)
        self.assertEqual(self.c.post("/api/m/hojas", json={"nombre": "x", "filas": [[""] * 21]}).status_code, 400)
        self.assertEqual(self.c.put(f"/api/m/hojas/{rid}", json={"nombre": "Costos", "filas": filas + [["a", "b", "c"]]}).status_code, 200)
        r = self.c.get(f"/api/m/hojas/{rid}/xlsx")
        self.assertEqual(r.status_code, 200)
        ws = load_workbook(io.BytesIO(r.data)).active
        self.assertEqual((ws["B2"].value, ws["C2"].value, ws["B3"].value), (3500, "007", 2.5))
        self.assertEqual((ws["A3"].value, ws["A3"].data_type), ("=1+1", "s"))  # texto, no fórmula
        self.assertEqual(ws["A4"].value, "a")

    def test_facturas_a_excel(self):
        from openpyxl import load_workbook
        self.entrar()
        self.c.post("/api/facturas", json={"cliente": "=HYPERLINK(1)", "impuesto": "iva19", "items": [ITEM]})
        ws = load_workbook(io.BytesIO(self.c.get("/api/facturas/xlsx").data)).active
        self.assertEqual((ws["A2"].value, ws["F2"].value, ws["C2"].data_type), ("FI-00001", 35700, "s"))

    def test_correos(self):
        self.activar(self.admin())
        self.entrar()
        con = {"para": "ana@correo.com", "asunto": "Hola", "mensaje": "Texto"}
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("FACTUIA_SMTP_HOST", None)
            r = self.c.post("/api/m/correos", json=con)
        self.assertEqual(r.status_code, 201)
        self.assertTrue(r.get_json()["estado"].startswith("borrador"))
        for malo in ({**con, "para": "no-es-correo"}, {**con, "asunto": "Hola\nBcc: x@y.com"}, {**con, "mensaje": ""}):
            self.assertEqual(self.c.post("/api/m/correos", json=malo).status_code, 400, malo)
        self.assertEqual(self.c.put(f"/api/m/correos/{r.get_json()['id']}", json=con).status_code, 400)

    def test_correo_enviado_por_smtp_y_limite_por_hora(self):
        self.activar(self.admin())
        self.entrar()
        enviados = []

        class FalsoSMTP:
            def __init__(self, *a, **k): pass
            def __enter__(self): return self
            def __exit__(self, *a): return False
            def starttls(self, **k): pass
            def login(self, *a): pass
            def send_message(self, msg): enviados.append(msg)

        con = {"para": "ana@correo.com", "asunto": "Hola", "mensaje": "Texto"}
        with mock.patch.dict(os.environ, {"FACTUIA_SMTP_HOST": "smtp.prueba", "FACTUIA_SMTP_FROM": "factuia@prueba.com"}), \
                mock.patch.object(appmod.smtplib, "SMTP", FalsoSMTP):
            self.assertEqual(self.c.post("/api/m/correos", json=con).get_json()["estado"], "enviado")
            for _ in range(appmod.MAX_CORREOS_HORA - 1):
                self.c.post("/api/m/correos", json=con)
            self.assertEqual(self.c.post("/api/m/correos", json=con).status_code, 429)
        self.assertEqual((enviados[0]["To"], enviados[0]["Subject"]), ("ana@correo.com", "Hola"))

    def test_publicidad(self):
        self.activar(self.admin())
        self.entrar()
        ok = {"red": "instagram", "titulo": "Lanzamiento", "texto": "Nuevo menú", "presupuesto": "150000.4",
              "inicio": "2026-11-01", "fin": "2026-11-30", "estado": "borrador"}
        r = self.c.post("/api/m/publicidad", json=ok)
        self.assertEqual((r.status_code, r.get_json()["presupuesto"]), (201, "150000"))
        for malo in ({**ok, "red": "myspace"}, {**ok, "estado": "x"}, {**ok, "fin": "2026-10-01"}, {**ok, "presupuesto": "-5"}):
            self.assertEqual(self.c.post("/api/m/publicidad", json=malo).status_code, 400, malo)


if __name__ == "__main__":
    unittest.main()
