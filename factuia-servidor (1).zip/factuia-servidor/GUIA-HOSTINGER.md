# Guía: publicar FactuIA en Hostinger

## La idea en un minuto

```
Cliente (navegador)  →  https://tudominio.com
                              │  HTTPS (candado)
                           Nginx            ← recibe las visitas y limita los intentos de acceso
                              │
                      Gunicorn + Flask      ← la aplicación (portal "/" y administración "/admin")
                              │
                       Base de datos SQLite ← usuarios, PIN, licencias, facturas, módulos
```

Todo vive en **un solo servidor** (un VPS). El portal del cliente y la administración son dos páginas de la misma aplicación.

## Qué necesitas

1. **Un VPS de Hostinger con Linux (Ubuntu 22.04 o 24.04).** Los planes de hosting compartido ("Web" y "Cloud") **no sirven**: Hostinger indica que Python y Flask solo funcionan en sus VPS. Es un servidor que administras tú, y esta guía te lo deja casi automático.
2. **Un dominio** (puedes comprarlo en Hostinger).
3. **Este proyecto** (`factuia-servidor.zip`).

## Paso a paso

**1. Contrata el VPS.** Elige la plantilla de sistema **Ubuntu 24.04** (o 22.04) y define la clave de `root`. Anota la **dirección IP** del servidor.

**2. Apunta el dominio al VPS.** En el DNS de tu dominio crea:
- un registro **A** con nombre `@` que apunte a la IP del VPS;
- un registro **A** con nombre `www` que apunte a la misma IP (opcional).

La propagación tarda de minutos a unas horas. Si el dominio no apunta bien, el instalador se detiene y te lo explica.

**3. Sube el proyecto.** Desde tu computador:
```bash
scp factuia-servidor.zip root@IP_DEL_VPS:/root/
```
(o con un cliente SFTP como FileZilla).

**4. Conéctate al servidor** por SSH (`ssh root@IP_DEL_VPS`) o con la terminal en el navegador que ofrece el panel de Hostinger.

**5. Instala.**
```bash
apt-get update && apt-get install -y unzip
unzip factuia-servidor.zip && cd factuia-servidor
sudo bash deploy/instalar.sh tudominio.com tu@correo.com
```
El instalador, en unos minutos: instala Python, Nginx y Certbot; crea un usuario sin privilegios para la aplicación; crea la base de datos con los usuarios de `semilla.json` y **borra ese archivo** (tiene las claves en texto plano); deja la aplicación arrancando sola; activa **HTTPS gratuito** (Let's Encrypt, se renueva solo); abre solo los puertos SSH, 80 y 443; y programa una copia de seguridad diaria.

**6. Pruébalo.** Abre `https://tudominio.com` (portal) y `https://tudominio.com/admin`.

**7. Cambia la clave del administrador** (hazlo ya; la inicial es fácil de adivinar). Empieza el comando con un espacio para que no quede en el historial:
```bash
 cd /opt/factuia && sudo -u factuia env FACTUIA_DB=/var/lib/factuia/factuia.db venv/bin/python inicializar.py --clave-admin 'TU_CLAVE_LARGA'
```

**8. (Opcional) Correos reales.** Edita `/etc/factuia.env` con los datos SMTP (ejemplo en `deploy/env.ejemplo`) y ejecuta `sudo systemctl restart factuia`.

## Mantenimiento

| Qué | Comando |
|---|---|
| Ver si funciona | `systemctl status factuia` |
| Ver errores en vivo | `journalctl -u factuia -f` |
| Reiniciar | `sudo systemctl restart factuia` |
| Actualizar la aplicación | sube el nuevo `.zip`, descomprímelo y ejecuta `sudo bash deploy/actualizar.sh` (conserva datos y claves) |
| Copias de seguridad | automáticas cada día a las 3:15 en `/var/backups/factuia` (14 días) |
| Bajar una copia a tu PC | `scp root@IP_DEL_VPS:/var/backups/factuia/factuia-AAAA-MM-DD.db .` |
| Restaurar una copia | `sudo systemctl stop factuia`, copia el archivo a `/var/lib/factuia/factuia.db`, `sudo chown factuia:factuia /var/lib/factuia/factuia.db`, `sudo systemctl start factuia` |
| Actualizaciones del sistema | `sudo apt-get update && sudo apt-get upgrade -y` (una vez al mes) |

Guarda también copias **fuera del servidor**: una copia que vive en el mismo VPS se pierde si el VPS falla.

## Si algo falla

| Síntoma | Causa probable y solución |
|---|---|
| El instalador dice que el dominio no apunta al servidor | El registro DNS aún no se propagó o está mal. Revísalo y espera unos minutos |
| Certbot falla | Mismo motivo, o los puertos 80 y 443 están cerrados. Si tienes un firewall activo en el panel de Hostinger, ábrelos también ahí |
| "502 Bad Gateway" | La aplicación está caída: `journalctl -u factuia -n 50 --no-pager` |
| "Demasiados intentos fallidos" | Es el bloqueo de seguridad: espera 5 minutos |
| Olvidaste la clave del administrador | Repite el paso 7 con una clave nueva |

## Antes de abrirlo a clientes reales

- **Claves y PIN fuertes.** Los de ejemplo son cortos y fáciles de adivinar: pide a cada cliente que cambie su PIN y crea claves largas para las empresas nuevas.
- **Textos legales.** Un sitio con usuarios y datos de clientes necesita aviso legal, política de privacidad y aviso de cookies (en Colombia, Ley 1581 de 2012). Hazlos revisar por un abogado. Esta versión todavía no los incluye en las páginas.
- **Facturas.** Son documentos de gestión internos, **no facturas electrónicas DIAN**. Para facturar legalmente hace falta habilitación o un proveedor tecnológico autorizado.
