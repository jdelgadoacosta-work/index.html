"""FactuIA: servidor Flask con el portal del cliente (/) y la administración (/admin)."""
import io
import json
import os
import re
import secrets
import smtplib
import sqlite3
import ssl
import time
from datetime import date, datetime, timedelta
from decimal import ROUND_HALF_UP, Decimal
from email.message import EmailMessage
from functools import wraps

from flask import Flask, g, jsonify, request, send_file, send_from_directory, session
from werkzeug.security import check_password_hash, generate_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
TARIFAS = {"iva19": 19, "iva5": 5, "impoconsumo8": 8, "excluido": 0}
MAX_FALLOS, BLOQUEO_SEGUNDOS = 5, 300
MSG_PAGO = "Acceso bloqueado: falta de pago en la suscripción."
MSG_INTENTOS = "Demasiados intentos fallidos. Espera unos minutos."
HASH_FALSO = generate_password_hash("sin-usuario")  # iguala el tiempo de respuesta con usuarios que no existen

ESQUEMA = """
CREATE TABLE IF NOT EXISTS clientes (
    usuario TEXT PRIMARY KEY, pw_hash TEXT NOT NULL, doc_hash TEXT NOT NULL, pin_hash TEXT NOT NULL,
    activo INTEGER NOT NULL DEFAULT 1, nit TEXT NOT NULL DEFAULT '', modulos TEXT NOT NULL DEFAULT '[]',
    fallos INTEGER NOT NULL DEFAULT 0, bloqueado_hasta REAL NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS facturas (
    id INTEGER PRIMARY KEY AUTOINCREMENT, cliente TEXT NOT NULL REFERENCES clientes(usuario),
    numero TEXT NOT NULL, fecha TEXT NOT NULL, nombre_cliente TEXT NOT NULL, items TEXT NOT NULL,
    base INTEGER NOT NULL, impuesto_tipo TEXT NOT NULL, impuesto INTEGER NOT NULL, total INTEGER NOT NULL,
    UNIQUE (cliente, numero));
CREATE TABLE IF NOT EXISTS config (clave TEXT PRIMARY KEY, valor TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS registros (
    id INTEGER PRIMARY KEY AUTOINCREMENT, cliente TEXT NOT NULL REFERENCES clientes(usuario),
    modulo TEXT NOT NULL, datos TEXT NOT NULL, creado TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_registros ON registros (cliente, modulo);
"""


def abrir(ruta):
    con = sqlite3.connect(ruta, isolation_level=None)  # transacciones manuales donde hacen falta
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con


def iniciar_db(ruta):
    con = abrir(ruta)
    con.executescript(ESQUEMA)
    if "modulos" not in [f["name"] for f in con.execute("PRAGMA table_info(clientes)")]:
        con.execute("ALTER TABLE clientes ADD COLUMN modulos TEXT NOT NULL DEFAULT '[]'")  # bases anteriores a los módulos
    con.close()


def sembrar(ruta, semilla, clave_admin=None):
    """Registra los clientes de la semilla (sin pisar los existentes) y la clave del administrador."""
    iniciar_db(ruta)
    con = abrir(ruta)
    for c in semilla.get("clientes", []):
        con.execute(
            "INSERT OR IGNORE INTO clientes (usuario, pw_hash, doc_hash, pin_hash) VALUES (?,?,?,?)",
            (c["usuario"].strip().lower(), generate_password_hash(c["password"]),
             generate_password_hash(c["documento"]), generate_password_hash(c["pin"])))
    clave = clave_admin or semilla.get("admin", {}).get("password")
    hay = con.execute("SELECT 1 FROM config WHERE clave='admin_hash'").fetchone()
    if clave and (clave_admin or not hay):
        con.execute("INSERT OR REPLACE INTO config VALUES ('admin_hash', ?)", (generate_password_hash(clave),))
    con.close()


def clave_secreta():
    if os.environ.get("FACTUIA_SECRET"):
        return os.environ["FACTUIA_SECRET"]
    ruta = os.path.join(BASE, ".secret")
    if not os.path.exists(ruta):
        with open(ruta, "w", encoding="utf-8") as f:
            f.write(secrets.token_hex(32))
        try:
            os.chmod(ruta, 0o600)
        except OSError:
            pass
    with open(ruta, encoding="utf-8") as f:
        return f.read().strip()


def a_pesos(valor):
    return int(Decimal(valor).quantize(Decimal(1), ROUND_HALF_UP))


def calcular_factura(d):
    """Valida los datos y calcula base, impuesto y total (pesos enteros)."""
    tipo, items = d.get("impuesto"), d.get("items")
    if tipo not in TARIFAS:
        raise ValueError("Impuesto no válido.")
    if not isinstance(items, list) or not 1 <= len(items) <= 50:
        raise ValueError("La factura necesita de 1 a 50 productos.")
    lineas, base = [], 0
    for it in items:
        try:
            desc, cant, precio = str(it["descripcion"]).strip(), int(it["cantidad"]), Decimal(str(it["precio"]))
        except (KeyError, TypeError, ValueError, ArithmeticError):
            raise ValueError("Hay un producto con datos no válidos.")
        if not desc or len(desc) > 120 or not 1 <= cant <= 100000 or not precio.is_finite() or not 0 < precio <= 10**9:
            raise ValueError("Cada producto necesita nombre, cantidad y precio mayores que 0.")
        sub = a_pesos(cant * precio)
        base += sub
        lineas.append({"descripcion": desc, "cantidad": cant, "precio": a_pesos(precio), "subtotal": sub})
    impuesto = a_pesos(Decimal(base) * TARIFAS[tipo] / 100)
    return lineas, base, tipo, impuesto, base + impuesto


REDES = ("facebook", "instagram", "tiktok", "x", "linkedin", "whatsapp")
# Módulos que el administrador puede activar por empresa: campo -> (tipo, límite u opciones, obligatorio)
MODULOS = {
    "calendario": {"titulo": ("txt", 120, True), "fecha": ("fecha", 0, True), "hora": ("hora", 0, False),
                   "notas": ("txt", 500, False)},
    "correos": {"para": ("email", 120, True), "asunto": ("txt", 150, True), "mensaje": ("txt", 5000, True)},
    "publicidad": {"red": ("opcion", REDES, True), "titulo": ("txt", 120, True), "texto": ("txt", 1000, True),
                   "presupuesto": ("num", 0, False), "inicio": ("fecha", 0, False), "fin": ("fecha", 0, False),
                   "estado": ("opcion", ("borrador", "programada", "publicada"), True)},
    "hojas": None,  # tiene su propia validación (limpiar_hoja)
}
UNA_LINEA = ("titulo", "asunto", "para")
MAX_REGISTROS, MAX_CORREOS_HORA = 1000, 20


def limpiar_modulos(valor):
    if not isinstance(valor, list) or any(not isinstance(m, str) or m not in MODULOS for m in valor):
        raise ValueError("Módulos no válidos.")
    return sorted(set(valor))


def limpiar(esquema, d):
    out = {}
    for campo, (tipo, lim, obligatorio) in esquema.items():
        v = d.get(campo)
        v = "" if v is None else str(v).strip()
        if not v:
            if obligatorio:
                raise ValueError(f"Falta el campo «{campo}».")
            out[campo] = ""
            continue
        if campo in UNA_LINEA and ("\n" in v or "\r" in v):
            raise ValueError(f"El campo «{campo}» debe ir en una sola línea.")
        try:
            if tipo == "txt" and len(v) > lim:
                raise ValueError(f"El campo «{campo}» admite hasta {lim} caracteres.")
            if tipo == "email" and not re.fullmatch(r"[^@\s,;<>]+@[^@\s,;<>]+\.[^@\s,;<>]+", v):
                raise ValueError("El correo no es válido.")
            if tipo == "fecha":
                try:
                    date.fromisoformat(v)
                except ValueError:
                    raise ValueError(f"«{campo}»: fecha no válida (AAAA-MM-DD).")
            if tipo == "hora":
                try:
                    datetime.strptime(v, "%H:%M")
                except ValueError:
                    raise ValueError(f"«{campo}»: hora no válida (HH:MM).")
            if tipo == "opcion" and v not in lim:
                raise ValueError(f"Opción no válida en «{campo}».")
            if tipo == "num":
                n = Decimal(v)
                if not n.is_finite() or not 0 <= n <= 10**10:
                    raise ValueError("El presupuesto no es válido.")
                v = str(a_pesos(n))
        except ArithmeticError:
            raise ValueError(f"Valor no válido en «{campo}».")
        out[campo] = v
    if out.get("inicio") and out.get("fin") and out["fin"] < out["inicio"]:
        raise ValueError("La fecha final no puede ser anterior a la inicial.")
    return out


def limpiar_hoja(d):
    nombre, filas = str(d.get("nombre", "")).strip(), d.get("filas")
    if not nombre or len(nombre) > 80:
        raise ValueError("La hoja necesita un nombre de hasta 80 caracteres.")
    if (not isinstance(filas, list) or not 1 <= len(filas) <= 100
            or any(not isinstance(f, list) or not 1 <= len(f) <= 20 for f in filas)):
        raise ValueError("La hoja admite de 1 a 100 filas y de 1 a 20 columnas.")
    return {"nombre": nombre, "filas": [["" if c is None else str(c)[:200] for c in f] for f in filas]}


def _celda(v):
    if isinstance(v, str):
        s = v.strip()
        if re.fullmatch(r"-?(0|[1-9]\d*)(\.\d+)?", s):  # los números con ceros a la izquierda se dejan como texto
            return float(s) if "." in s else int(s)
        return v or None
    return v


def libro_xlsx(titulo, filas):
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.title = re.sub(r"[\\/*?:\[\]]", "_", titulo)[:31] or "Hoja"
    for fila in filas:
        ws.append([_celda(v) for v in fila])
    for fila in ws.iter_rows():
        for c in fila:
            if isinstance(c.value, str) and c.value.startswith("="):
                c.data_type = "s"  # lo escrito por el usuario es texto, nunca una fórmula
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


def enviar_xlsx(buf, nombre):
    return send_file(buf, as_attachment=True, download_name=re.sub(r"[^\w.-]+", "_", nombre) + ".xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


def enviar_correo(usuario, datos):
    """Envía por SMTP si hay servidor configurado; si no, queda como borrador."""
    host = os.environ.get("FACTUIA_SMTP_HOST")
    if not host:
        return "borrador (SMTP sin configurar)"
    msg = EmailMessage()
    msg["From"] = os.environ.get("FACTUIA_SMTP_FROM") or os.environ.get("FACTUIA_SMTP_USER", "")
    msg["To"], msg["Subject"] = datos["para"], datos["asunto"]
    msg.set_content(f"{datos['mensaje']}\n\n--\nEnviado desde FactuIA por {usuario}")
    try:
        with smtplib.SMTP(host, int(os.environ.get("FACTUIA_SMTP_PORT", "587")), timeout=15) as s:
            s.starttls(context=ssl.create_default_context())
            if os.environ.get("FACTUIA_SMTP_USER"):
                s.login(os.environ["FACTUIA_SMTP_USER"], os.environ.get("FACTUIA_SMTP_PASSWORD", ""))
            s.send_message(msg)
        return "enviado"
    except (OSError, smtplib.SMTPException, ValueError) as e:
        return "error: " + str(e)[:120]


def crear_app(ruta_db=None, secreto=None):
    app = Flask(__name__, static_folder=None)
    app.config.update(
        DB=ruta_db or os.environ.get("FACTUIA_DB", os.path.join(BASE, "factuia.db")),
        SECRET_KEY=secreto or clave_secreta(), MAX_CONTENT_LENGTH=256 * 1024,
        SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("FACTUIA_HTTPS") == "1")
    iniciar_db(app.config["DB"])

    def db():
        if "db" not in g:
            g.db = abrir(app.config["DB"])
        return g.db

    @app.teardown_appcontext
    def cerrar(_):
        con = g.pop("db", None)
        if con:
            con.close()

    def error(msg, codigo):
        return jsonify(error=msg), codigo

    def cfg(clave, defecto="0"):
        fila = db().execute("SELECT valor FROM config WHERE clave=?", (clave,)).fetchone()
        return fila["valor"] if fila else defecto

    def poner_cfg(clave, valor):
        db().execute("INSERT OR REPLACE INTO config VALUES (?,?)", (clave, str(valor)))

    @app.before_request
    def solo_json():
        # Un POST con JSON no se puede enviar desde otro sitio sin permiso del navegador: frena el CSRF.
        if request.path.startswith("/api/") and request.method in ("POST", "PUT", "PATCH") and not request.is_json:
            return error("Se esperaba JSON.", 415)

    @app.after_request
    def cabeceras(r):
        r.headers.update({"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY",
                          "Referrer-Policy": "no-referrer", "Cache-Control": "no-store"})
        if request.path.startswith(("/admin", "/api/admin")):
            r.headers["X-Robots-Tag"] = "noindex, nofollow"
        return r

    def con_cliente(f):
        @wraps(f)
        def envoltura(*a, **k):
            u = session.get("cliente")
            c = db().execute("SELECT * FROM clientes WHERE usuario=?", (u,)).fetchone() if u else None
            if not c:
                return error("Sesión no iniciada.", 401)
            if not c["activo"]:
                return error(MSG_PAGO, 403)
            return f(c, *a, **k)
        return envoltura

    def con_admin(f):
        @wraps(f)
        def envoltura(*a, **k):
            if not session.get("admin"):
                return error("Sesión de administración no iniciada.", 401)
            return f(*a, **k)
        return envoltura

    # ---------- Páginas ----------
    @app.get("/")
    def portal():
        return send_from_directory(os.path.join(BASE, "static"), "index.html")

    @app.get("/admin")
    def admin():
        return send_from_directory(os.path.join(BASE, "static"), "admin.html")

    # ---------- Portal del cliente ----------
    @app.post("/api/login")
    def login():
        d = request.get_json(silent=True) or {}
        usuario = str(d.get("usuario", "")).strip().lower()
        c = db().execute("SELECT * FROM clientes WHERE usuario=?", (usuario,)).fetchone()
        if c and c["bloqueado_hasta"] > time.time():
            return error(MSG_INTENTOS, 429)
        res = [check_password_hash(c[col] if c else HASH_FALSO, str(d.get(campo, "")))
               for col, campo in (("pw_hash", "password"), ("doc_hash", "documento"), ("pin_hash", "pin"))]
        if not (c and all(res)):
            if c:
                n = c["fallos"] + 1
                if n >= MAX_FALLOS:
                    db().execute("UPDATE clientes SET fallos=0, bloqueado_hasta=? WHERE usuario=?",
                                 (time.time() + BLOQUEO_SEGUNDOS, usuario))
                else:
                    db().execute("UPDATE clientes SET fallos=? WHERE usuario=?", (n, usuario))
            return error("Credenciales inválidas", 401)
        db().execute("UPDATE clientes SET fallos=0 WHERE usuario=?", (usuario,))
        if not c["activo"]:
            return error(MSG_PAGO, 403)
        session["cliente"] = usuario
        return jsonify(usuario=usuario, nit=c["nit"], modulos=json.loads(c["modulos"]))

    @app.post("/api/logout")
    def logout():
        session.pop("cliente", None)
        return jsonify(ok=True)

    @app.get("/api/yo")
    @con_cliente
    def yo(c):
        return jsonify(usuario=c["usuario"], nit=c["nit"], modulos=json.loads(c["modulos"]))

    @app.post("/api/pin")
    @con_cliente
    def cambiar_pin(c):
        d = request.get_json(silent=True) or {}
        actual, nuevo = str(d.get("actual", "")), str(d.get("nuevo", ""))
        if not check_password_hash(c["pin_hash"], actual):
            return error("El PIN actual no es correcto.", 400)
        if not re.fullmatch(r"\d{4}", nuevo):
            return error("El PIN nuevo debe tener 4 dígitos.", 400)
        if nuevo == actual:
            return error("El PIN nuevo debe ser distinto del actual.", 400)
        db().execute("UPDATE clientes SET pin_hash=? WHERE usuario=?", (generate_password_hash(nuevo), c["usuario"]))
        return jsonify(ok=True)

    @app.put("/api/nit")
    @con_cliente
    def guardar_nit(c):
        nit = str((request.get_json(silent=True) or {}).get("nit", "")).strip()
        if len(nit) > 30:
            return error("El NIT es demasiado largo.", 400)
        db().execute("UPDATE clientes SET nit=? WHERE usuario=?", (nit, c["usuario"]))
        return jsonify(nit=nit)

    @app.get("/api/facturas")
    @con_cliente
    def listar_facturas(c):
        filas = db().execute("SELECT * FROM facturas WHERE cliente=? ORDER BY id DESC", (c["usuario"],)).fetchall()
        return jsonify([{"numero": f["numero"], "fecha": f["fecha"], "cliente": f["nombre_cliente"],
                         "items": json.loads(f["items"]), "base": f["base"], "impuesto_tipo": f["impuesto_tipo"],
                         "impuesto": f["impuesto"], "total": f["total"]} for f in filas])

    @app.post("/api/facturas")
    @con_cliente
    def crear_factura(c):
        d = request.get_json(silent=True) or {}
        try:
            lineas, base, tipo, impuesto, total = calcular_factura(d)
        except ValueError as e:
            return error(str(e), 400)
        nombre = str(d.get("cliente", "")).strip()[:120] or "Consumidor final"
        con = db()
        con.execute("BEGIN IMMEDIATE")  # la numeración no se repite aunque lleguen dos facturas a la vez
        try:
            n = con.execute("SELECT COUNT(*) FROM facturas WHERE cliente=?", (c["usuario"],)).fetchone()[0] + 1
            numero, fecha = f"FI-{n:05d}", datetime.now().isoformat(timespec="seconds")
            con.execute("INSERT INTO facturas (cliente, numero, fecha, nombre_cliente, items, base, impuesto_tipo, impuesto, total)"
                        " VALUES (?,?,?,?,?,?,?,?,?)",
                        (c["usuario"], numero, fecha, nombre, json.dumps(lineas, ensure_ascii=False), base, tipo, impuesto, total))
            con.execute("COMMIT")
        except Exception:
            con.execute("ROLLBACK")
            raise
        return jsonify(numero=numero, fecha=fecha, cliente=nombre, items=lineas, base=base,
                       impuesto_tipo=tipo, impuesto=impuesto, total=total), 201

    # ---------- Módulos opcionales (los activa el administrador) ----------
    def chequear_modulo(c, modulo):
        if modulo not in MODULOS:
            return error("Módulo desconocido.", 404)
        if modulo not in json.loads(c["modulos"]):
            return error("Este módulo no está activo para tu empresa.", 404)

    def limpiar_datos(modulo, d):
        return limpiar_hoja(d) if modulo == "hojas" else limpiar(MODULOS[modulo], d)

    @app.get("/api/m/<modulo>")
    @con_cliente
    def m_listar(c, modulo):
        fallo = chequear_modulo(c, modulo)
        if fallo:
            return fallo
        filas = db().execute("SELECT id, datos, creado FROM registros WHERE cliente=? AND modulo=? ORDER BY id DESC",
                             (c["usuario"], modulo)).fetchall()
        return jsonify([{"id": f["id"], "creado": f["creado"], **json.loads(f["datos"])} for f in filas])

    @app.post("/api/m/<modulo>")
    @con_cliente
    def m_crear(c, modulo):
        fallo = chequear_modulo(c, modulo)
        if fallo:
            return fallo
        try:
            datos = limpiar_datos(modulo, request.get_json(silent=True) or {})
        except ValueError as e:
            return error(str(e), 400)
        ahora = datetime.now().isoformat(timespec="seconds")
        con = db()
        if con.execute("SELECT COUNT(*) FROM registros WHERE cliente=? AND modulo=?", (c["usuario"], modulo)).fetchone()[0] >= MAX_REGISTROS:
            return error("Alcanzaste el límite de registros de este módulo.", 400)
        if modulo == "correos":
            hace_1h = (datetime.now() - timedelta(hours=1)).isoformat(timespec="seconds")
            enviados = con.execute("SELECT COUNT(*) FROM registros WHERE cliente=? AND modulo='correos' AND creado>=?",
                                   (c["usuario"], hace_1h)).fetchone()[0]
            if enviados >= MAX_CORREOS_HORA:
                return error(f"Límite de {MAX_CORREOS_HORA} correos por hora alcanzado.", 429)
            datos["estado"] = enviar_correo(c["usuario"], datos)
        cur = con.execute("INSERT INTO registros (cliente, modulo, datos, creado) VALUES (?,?,?,?)",
                          (c["usuario"], modulo, json.dumps(datos, ensure_ascii=False), ahora))
        return jsonify(id=cur.lastrowid, creado=ahora, **datos), 201

    @app.put("/api/m/<modulo>/<int:rid>")
    @con_cliente
    def m_editar(c, modulo, rid):
        fallo = chequear_modulo(c, modulo)
        if fallo:
            return fallo
        if modulo == "correos":
            return error("Los correos enviados no se pueden editar.", 400)
        try:
            datos = limpiar_datos(modulo, request.get_json(silent=True) or {})
        except ValueError as e:
            return error(str(e), 400)
        cur = db().execute("UPDATE registros SET datos=? WHERE id=? AND cliente=? AND modulo=?",
                           (json.dumps(datos, ensure_ascii=False), rid, c["usuario"], modulo))
        return jsonify(id=rid, **datos) if cur.rowcount else error("No encontrado.", 404)

    @app.delete("/api/m/<modulo>/<int:rid>")
    @con_cliente
    def m_borrar(c, modulo, rid):
        fallo = chequear_modulo(c, modulo)
        if fallo:
            return fallo
        cur = db().execute("DELETE FROM registros WHERE id=? AND cliente=? AND modulo=?", (rid, c["usuario"], modulo))
        return jsonify(ok=True) if cur.rowcount else error("No encontrado.", 404)

    @app.get("/api/m/hojas/<int:rid>/xlsx")
    @con_cliente
    def hoja_xlsx(c, rid):
        fallo = chequear_modulo(c, "hojas")
        if fallo:
            return fallo
        f = db().execute("SELECT datos FROM registros WHERE id=? AND cliente=? AND modulo='hojas'",
                         (rid, c["usuario"])).fetchone()
        if not f:
            return error("Hoja no encontrada.", 404)
        h = json.loads(f["datos"])
        return enviar_xlsx(libro_xlsx(h["nombre"], h["filas"]), h["nombre"])

    @app.get("/api/facturas/xlsx")
    @con_cliente
    def facturas_xlsx(c):
        filas = [["Número", "Fecha", "Cliente", "Base", "Impuesto", "Total"]]
        for f in db().execute("SELECT * FROM facturas WHERE cliente=? ORDER BY id", (c["usuario"],)):
            filas.append([f["numero"], f["fecha"], f["nombre_cliente"], f["base"], f["impuesto"], f["total"]])
        return enviar_xlsx(libro_xlsx("Facturas", filas), "facturas")

    # ---------- Administración ----------
    @app.post("/api/admin/login")
    def admin_login():
        if float(cfg("admin_bloqueo")) > time.time():
            return error(MSG_INTENTOS, 429)
        clave = str((request.get_json(silent=True) or {}).get("password", ""))
        if check_password_hash(cfg("admin_hash", HASH_FALSO), clave):
            poner_cfg("admin_fallos", 0)
            session["admin"] = True
            return jsonify(ok=True)
        n = int(cfg("admin_fallos")) + 1
        if n >= MAX_FALLOS:
            poner_cfg("admin_fallos", 0)
            poner_cfg("admin_bloqueo", time.time() + BLOQUEO_SEGUNDOS)
        else:
            poner_cfg("admin_fallos", n)
        return error("Clave incorrecta", 401)

    @app.post("/api/admin/logout")
    def admin_logout():
        session.pop("admin", None)
        return jsonify(ok=True)

    @app.get("/api/admin/clientes")
    @con_admin
    def admin_clientes():
        filas = db().execute(
            "SELECT c.usuario, c.activo, c.modulos, COUNT(f.id) AS facturas, COALESCE(SUM(f.total), 0) AS total "
            "FROM clientes c LEFT JOIN facturas f ON f.cliente = c.usuario GROUP BY c.usuario ORDER BY c.usuario").fetchall()
        return jsonify([dict(f) | {"activo": bool(f["activo"]), "modulos": json.loads(f["modulos"])} for f in filas])

    @app.post("/api/admin/clientes")
    @con_admin
    def admin_agregar():
        d = request.get_json(silent=True) or {}
        usuario = str(d.get("usuario", "")).strip().lower()
        pw, doc, pin = (str(d.get(k, "")) for k in ("password", "documento", "pin"))
        if not re.fullmatch(r"[a-z0-9_-]{3,30}", usuario):
            return error("Usuario: de 3 a 30 letras minúsculas, números, _ o -.", 400)
        if len(pw) < 6 or not doc or not re.fullmatch(r"\d{4}", pin):
            return error("Contraseña de 6+ caracteres, documento y PIN de 4 dígitos.", 400)
        try:
            modulos = limpiar_modulos(d.get("modulos", []))
        except ValueError as e:
            return error(str(e), 400)
        try:
            db().execute("INSERT INTO clientes (usuario, pw_hash, doc_hash, pin_hash, modulos) VALUES (?,?,?,?,?)",
                         (usuario, generate_password_hash(pw), generate_password_hash(doc),
                          generate_password_hash(pin), json.dumps(modulos)))
        except sqlite3.IntegrityError:
            return error("Ese cliente ya existe.", 409)
        return jsonify(usuario=usuario), 201

    @app.patch("/api/admin/clientes/<usuario>")
    @con_admin
    def admin_actualizar(usuario):
        d = request.get_json(silent=True) or {}
        if not db().execute("SELECT 1 FROM clientes WHERE usuario=?", (usuario,)).fetchone():
            return error("Cliente no encontrado.", 404)
        if "activo" not in d and "modulos" not in d:
            return error("Falta el estado (activo) o los módulos.", 400)
        if "activo" in d:
            if not isinstance(d["activo"], bool):
                return error("El estado debe ser true o false.", 400)
            db().execute("UPDATE clientes SET activo=? WHERE usuario=?", (int(d["activo"]), usuario))
        if "modulos" in d:
            try:
                modulos = limpiar_modulos(d["modulos"])
            except ValueError as e:
                return error(str(e), 400)
            db().execute("UPDATE clientes SET modulos=? WHERE usuario=?", (json.dumps(modulos), usuario))
        return jsonify(ok=True)

    return app


if __name__ == "__main__":
    crear_app().run(host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT", "5000")))
